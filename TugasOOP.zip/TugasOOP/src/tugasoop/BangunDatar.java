package tugasoop;
import java.util.Scanner;
public class BangunDatar {
    public static void main(String[] args) {
        Scanner scanInput = new Scanner(System.in);
        int menu;            
        System.out.println("===Bangun Datar===");
        System.out.println("1.Persegi");
        System.out.println("2.Persegi Panjang");
        System.out.println("3.Lingkaran");
        System.out.println("Pilih : ");
        menu = scanInput.nextInt();
        if (menu==1)
        {
             int sisi, menus;
             Persegi Persegi1 = new Persegi();
             Persegi1.setSisi(0);
             System.out.println("--Persegi---");
             System.out.print("Panjang Sisi = ");
             sisi = scanInput.nextInt();
             Persegi1.setSisi(sisi);
             Persegi1.Luas();
             Persegi1.Keliling();
             System.out.println("===Bangun 3 Dimensi===");
             System.out.println("1.Prisma persegi");
             System.out.println("2.Limas persegi");
             System.out.println("Pilih : ");
             menus = scanInput.nextInt();
             if(menus==1)
             {
                 Persegi Kubus = new Persegi();
                 Kubus.setSisi(0);
                 System.out.println("---Prisma Persegi---");
                 System.out.print("Panjang Sisi : ");
                 sisi = scanInput.nextInt();
                 Kubus.setSisi(sisi);
                 Kubus.Luasp();
                 Kubus.Volumep();
             }
             if (menus==2) 
             {
                 int tinggi, tinggis3;
                 Persegi Limasp = new Persegi();
                 Limasp.setSisi(0);
                 System.out.println("---Limas Persegi---");
                 System.out.print("Panjang sisi : ");
                 sisi = scanInput.nextInt();
                 Limasp.setSisi(sisi);
                 System.out.print("Tinggi limas : ");
                 tinggi = scanInput.nextInt();
                 Limasp.setTinggi(tinggi);
                 System.out.print("Tinggi selimut : ");
                 tinggis3 = scanInput.nextInt();
                 Limasp.setTinggis3(tinggis3);
                 Limasp.Luasl();
                 Limasp.Volumel();
             }
        }
        if (menu==2) 
        {
             int menus;
             int panjang,lebar,tinggi;
             Persegipanjang ppanjang1 = new Persegipanjang();
             ppanjang1.setPanjang(0);
             System.out.println("---Persegi Panjang---");
             System.out.print("Panjang    : ");
             panjang = scanInput.nextInt();
             ppanjang1.setPanjang(panjang);
             ppanjang1.setLebar(0);
             System.out.print("Lebar      : ");
             lebar = scanInput.nextInt();
             ppanjang1.setLebar(lebar);
             ppanjang1.getLuas();
             ppanjang1.getKeliling();
             System.out.println("===Bangun 3 Dimensi===");
             System.out.println("1.Prisma persegi panjang");
             System.out.println("2.Limas persegi panjang");
             System.out.println("Pilih : ");
             menus = scanInput.nextInt();
             if (menus==1) 
             {
                 Persegipanjang Balok = new Persegipanjang();
                 System.out.println("---Prisma Persegi---");
                 Balok.setPanjang(0);
                 System.out.print("Panjang : ");
                 panjang = scanInput.nextInt();
                 Balok.setPanjang(panjang);
                 System.out.print("Lebar : ");
                 lebar = scanInput.nextInt();
                 Balok.setLebar(lebar);
                 System.out.print("Tinggi : ");
                 tinggi = scanInput.nextInt();
                 Balok.setTinggi(tinggi);                
                 Balok.getLuasb();
                 Balok.getVolumeb();
             }
             if (menus==2) 
             {
                 int tinggil,tinggis;
                 Persegipanjang Limaspp = new Persegipanjang();
                 System.out.println("---Prisma Persegi---");
                 Limaspp.setPanjang(0);
                 System.out.print("Panjang : ");
                 panjang = scanInput.nextInt();
                 Limaspp.setPanjang(panjang);
                 System.out.print("Lebar : ");
                 lebar = scanInput.nextInt();
                 Limaspp.setLebar(lebar);
                 System.out.print("Tinggi limas : ");
                 tinggil = scanInput.nextInt();
                 Limaspp.setTinggil(tinggil);
                 System.out.print("Tinggi selimut limas : ");
                 tinggis = scanInput.nextInt();
                 Limaspp.setTinggis(tinggis);
                 Limaspp.getLuasl();
                 Limaspp.getVolumel();
             }
             
        }
        
        if (menu==3) 
        {
            int sisi, menus, Jarijari, tinggit, tinggik, gp;
             Lingkaran ling1 = new Lingkaran();
             ling1.setJarijari(0);
             System.out.println("--Lingkaran---");
             System.out.print("Jari jari = ");
             Jarijari = scanInput.nextInt();
             ling1.setJarijari(Jarijari);
             ling1.Luas();
             ling1.Keliling();
             System.out.println("===Bangun 3 Dimensi===");
             System.out.println("1.Prisma Lingkaran");
             System.out.println("2.Limas Lingkaran");
             System.out.println("Pilih : ");
             menus = scanInput.nextInt();
             if (menus==1) 
             {
                 Lingkaran tabung = new Lingkaran();
                 System.out.println("---Prisma lingkaran---");
                 tabung.setJarijari(0);
                 System.out.print("Jari jari alas : ");
                 Jarijari = scanInput.nextInt();
                 tabung.setJarijari(Jarijari);
                 System.out.print("Tinggi prisma : ");
                 tinggit = scanInput.nextInt();
                 tabung.setTinggit(tinggit);
                 tabung.Volumet();
                 tabung.Luaspt();
             }
             if (menus==2) 
             {
                 
                 Lingkaran tabung1 = new Lingkaran();
                 System.out.println("---Limas lingkaran---");
                 tabung1.setJarijari(0);
                 System.out.print("Jari jari alas : ");
                 Jarijari = scanInput.nextInt();
                 tabung1.setJarijari(Jarijari);
                 tabung1.setTinggik(0);
                 System.out.print("Tinggi limas : ");
                 tinggik = scanInput.nextInt();
                 tabung1.setTinggik(tinggik);
                  tabung1.setGp(0);
                 System.out.print("Panjang garis pelukis : ");
                 gp = scanInput.nextInt();
                 tabung1.setGp(gp);
                 tabung1.Volumek();
                 tabung1.Luaspk();
             }
        }
    }
    
}
