package tugasoop;
public class Persegi extends BangunDatar {
    private int Sisi, tinggi, tinggis3;
    int luas, keliling;
    public void setSisi(int Sisi) 
    {
        this.Sisi = Sisi;
    }
    public int getSisi()
    {
        return Sisi;
    }

    public int getTinggi() {
        return tinggi;
    }

    public void setTinggi(int tinggi) {
        this.tinggi = tinggi;
    }   

    public int getTinggis3() {
        return tinggis3;
    }

    public void setTinggis3(int tinggis3) {
        this.tinggis3 = tinggis3;
    }
    
    public void Luas()
    {
        luas=Sisi*Sisi;
        System.out.println("Luas Persegi = " + luas);
    }
    public void Keliling()
    {
        keliling=Sisi*4;
        System.out.println("Keliling Persegi = " + keliling);
    }
    
    public void Luasp()
    {
        int luasp= 6*(Sisi*Sisi);
        System.out.println("Luas permukaan = " + luasp);
    }
    public void Volumep()
    {
        int volumep = Sisi*Sisi;
        System.out.println("Volume = " + volumep);
    }
    
    public void Luasl()
    {
        int luasl = 4*((Sisi*tinggis3)/2)+(Sisi*Sisi);
        System.out.println("Luas permukaan limas = " + luasl);
    }
    
    public void Volumel()
    {
        int volumel = (1/3*(Sisi*Sisi) * tinggi);
        System.out.println("Volume limas = " + volumel);
    }
}