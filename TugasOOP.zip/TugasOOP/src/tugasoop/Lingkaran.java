package tugasoop;
public class Lingkaran extends BangunDatar {
    private int Jarijari, tinggit, gp, tinggik;
    int luas,keliling;
    public int getJarijari() {
        return Jarijari;
    }

    public void setJarijari(int Jarijari) {
        this.Jarijari = Jarijari;
    }
   
     public void Luas()
    {
        luas = 22/7*Jarijari*Jarijari;
        System.out.println("Luas Lingkaran = " + luas);
    }
    public void Keliling()
    {
        keliling = 22/7*2*Jarijari;
        System.out.println("Keliling Lingkaran = " + keliling);
    }

    public int getTinggit() {
        return tinggit;
    }

    public void setTinggit(int tinggit) {
        this.tinggit = tinggit;
    }
    
     public void Volumet()
    {
        int volume = 22/7*Jarijari*Jarijari*tinggit;
        System.out.println("Volume prisma = " + volume);
    }
    public void Luaspt()
    {
        int Luasp = 2*22/7*Jarijari*(Jarijari+tinggit);
        System.out.println("Luas permukaan prisma = " + Luasp);
    }

    public int getGp() {
        return gp;
    }

    public void setGp(int gp) {
        this.gp = gp;
    }

    public int getTinggik() {
        return tinggik;
    }

    public void setTinggik(int tinggik) {
        this.tinggik = tinggik;
    }
    
     public void Volumek()
    {
        int volumek = 1/3*22/7*Jarijari*Jarijari*tinggik;
        System.out.println("Volume limas = " + volumek);
    }
    public void Luaspk()
    {
        int Luasp = 22/7*Jarijari*(Jarijari+gp);
        System.out.println("Luas permukaan limas = " + Luasp);
    }
    
}