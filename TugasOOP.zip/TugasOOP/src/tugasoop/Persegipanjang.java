package tugasoop;
public class Persegipanjang extends BangunDatar{
    private int panjang;
    private int lebar;
    private int tinggi;
    private int tinggil;
    private int tinggis;
    int luas, keliling;

    public void setPanjang(int panjang) 
    {
        this.panjang = panjang;
    }

    public int getLebar() 
    {
        return this.lebar;
    }

    public int getTinggil() {
        return tinggil;
    }

    public void setTinggil(int tinggil) {
        this.tinggil = tinggil;
    }
    
    public int getTinggi() {
        return tinggi;
    }

    public void setTinggi(int tinggi) {
        this.tinggi = tinggi;
    }

    public int getTinggis() {
        return tinggis;
    }

    public void setTinggis(int tinggis) {
        this.tinggis = tinggis;
    }
    
    public int getPanjang() 
    {
        return this.panjang;
    }

    public void setLebar(int lebar) 
    {
        this.lebar = lebar;
    }
    
    public void getLuas()
    {
        this.luas = this.panjang*this.lebar;
        System.out.println("Luas PersegiPanjang = " + luas);
    }
    public void getKeliling()
    {
        keliling = 2*(panjang+lebar);
        System.out.println("keliling PersegiPanjang = " + keliling);
    }
    
    public void getVolumeb()
    {
        int volumeb = panjang*lebar*tinggi;
        System.out.println("Volume Prisma = " + volumeb);
    }

    public void getLuasb()
    {
        int luasb = 2*(panjang*lebar+panjang*tinggi+lebar*tinggi);
        System.out.println("Luas Permukan Prisma = " + luasb);
    }
    
    public void getVolumel()
    {
        int volumel = 1/3*(panjang*lebar)*tinggi;
        System.out.println("Volume Limas = " + volumel);
    }
    
    public void getLuasl()
    {
        int luasl = 2*(panjang*tinggis/2) + 2*(lebar*tinggis/2) + (panjang*lebar);
        System.out.println("Luas permukaan limas = " + luasl);
    }
}