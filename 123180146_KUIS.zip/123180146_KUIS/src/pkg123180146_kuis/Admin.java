/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg123180146_kuis;

/**
 *
 * @author Nadifsa
 */
public class Admin extends Nilai 
{
    private int tesadmin;
    public int naadmin;

    public int getTesadmin() {
        return tesadmin;
    }

    public void setTesadmin(int tesadmin) {
        this.tesadmin = tesadmin;
    }    
}
