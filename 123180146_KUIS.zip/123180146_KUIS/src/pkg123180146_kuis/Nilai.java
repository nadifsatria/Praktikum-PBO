/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg123180146_kuis;

/**
 *
 * @author Nadifsa
 */
public class Nilai {
    private String nama;
    private int nim;
    private int testulis;
    private int tescoding;
    private int teswancara; 

    public int getNim() {
        return nim;
    }

    public void setNim(int nim) {
        this.nim = nim;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public void setTestulis(int testulis) {
        this.testulis = testulis;
    }

    public void setTescoding(int tescoding) {
        this.tescoding = tescoding;
    }

    public void setTeswancara(int teswancara) {
        this.teswancara = teswancara;
    }
    
    public int getTestulis() {
        return testulis;
    }

    public int getTescoding() {
        return tescoding;
    }

    public int getTeswancara() {
        return teswancara;
    }   
}
