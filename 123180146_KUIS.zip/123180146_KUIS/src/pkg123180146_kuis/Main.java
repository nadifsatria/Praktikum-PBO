/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg123180146_kuis;
import java.util.Scanner;

/**
 *
 * @author Nadifsa
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        // TODO code application logic here 
        Scanner scanInput = new Scanner(System.in);
        String nama, lagi = "Y"; 
        int menu, nim, n,testulis,tescoding,teswancara,tesaslab,tesadmin,naaslab,naadmin;
        while(lagi.equals("Y"))
        {
        try { 
        System.out.println("===Form Pendaftaran===");
        System.out.println("1.Asisten laboratorium");
        System.out.println("2.Admin laboratorium");
        System.out.print("Pilih = "); 
        menu = scanInput.nextInt(); 
        if (menu==1) 
        {
            System.out.println("---Form Asisten Laboratorium---");
            System.out.print("Berapa banyak data : ");
            n = scanInput.nextInt();
            for (int i = 1; i <=n; i++) 
            {
                System.out.println("Data ke - "+i);
                Nilai nilai1 = new Nilai(); 
                System.out.print("Input Nim   : ");
                nim = scanInput.nextInt();
                nilai1.setNim(nim);
                System.out.print("Input Nama  : ");
                nama = scanInput.next();
                nilai1.setNama(nama); 
                System.out.print("Input Nilai Tes Tulis   : ");
                testulis = scanInput.nextInt();
                nilai1.setTestulis(testulis);     
                System.out.print("Input Nilai Tes Coding   : ");
                tescoding = scanInput.nextInt();
                nilai1.setTescoding(tescoding);  
                System.out.print("Input Nilai Tes Wawancara   : ");
                teswancara = scanInput.nextInt();
                nilai1.setTeswancara(teswancara);
                Aslab aslab1 = new Aslab(); 
                System.out.print("Input Nilai Tes Microteaching   : ");
                tesaslab = scanInput.nextInt();
                aslab1.setTesaslab(tesaslab);  
                naaslab = (testulis + tescoding + teswancara + tesaslab) / 4;
                System.out.println("Nilai akhir = " + naaslab);
                if (naaslab > 85) 
                {
                    System.out.println("Keterngan : Lolos ");
                    System.out.println("Selamat Kepada nim " +nim+" telah DITERIMA sebagai Asisten Laboratorium");
                }
                else if (naaslab <= 85) 
                {
                    System.out.println("Keterngan : Tidak Lolos ");
                    System.out.println("Mohon maaf kepada nim " + nim+" TIDAK DITERIMA sebagai Asisten Laboratorium");
            
                } 
            } 
               System.out.println("Kembali ke menu ? Y/T");
              lagi = scanInput.next();
        } 
        else if (menu==2)
        {
            System.out.println("---Form Admin Laboratorium---");
            System.out.print ("Berapa banyak data : ");
            n = scanInput.nextInt();
            for (int i = 1; i <=n; i++) 
            {
                System.out.println("Data ke - "+i);
                Nilai nilai1 = new Nilai(); 
                System.out.print("Input Nim   : ");
                nim = scanInput.nextInt();
                nilai1.setNim(nim);
                System.out.print("Input Nama  : ");
                nama = scanInput.next();
                nilai1.setNama(nama); 
                System.out.print("Input Nilai Tes Tulis   : ");
                testulis = scanInput.nextInt();
                nilai1.setTestulis(testulis); 
                System.out.print("Input Nilai Tes Coding   : ");
                tescoding = scanInput.nextInt();
                nilai1.setTescoding(tescoding); 
                System.out.print("Input Nilai Tes Wawancara   : ");
                teswancara = scanInput.nextInt();
                nilai1.setTeswancara(teswancara);
                Admin admin1 = new Admin(); 
                System.out.print("Input Nilai Tes Praktek Jaringan   : ");
                tesadmin = scanInput.nextInt();
                admin1.setTesadmin(tesadmin); 
                naadmin = (testulis + tescoding + teswancara + tesadmin) / 4;
                System.out.println("Nilai akhir = " + naadmin);
                if (naadmin > 85) 
                {
                    System.out.println("Keterngan : Lolos ");
                    System.out.println("Selamat Kepada nim " +nim+" telah DITERIMA sebagai Admin Laboratorium");
                }
                else if (naadmin <= 85) 
                {
                    System.out.println("Keterngan : Tidak Lolos ");
                    System.out.println("Mohon maaf kepada nim " + nim+" TIDAK DITERIMA sebagai Admin Laboratorium");          
                }
            }
               System.out.println("Kembali ke menu ? Y/T");
              lagi = scanInput.next();
        }
         
        } catch (Exception e) {
                System.out.println("Nilai harus bilangan bulat"); 
                scanInput.nextLine();
              System.out.println("Kembali ke menu ? Y/T");
              lagi = scanInput.next();
        }

    }
    
    }
    } 
