
package tugas4;

import java.awt.Color;
import javax.swing.*;
public class GUI extends JFrame
{
    final JTextField fnama = new JTextField(10);
    JLabel lnama = new JLabel (" Nama Lengkap "); 
    final JTextField fnim = new JTextField(10);
    JLabel lnim = new JLabel (" Nim "); 
    final JTextField fjurusan = new JTextField(10);
    JLabel ljurusan = new JLabel (" Jurusan "); 
    JLabel lagama = new JLabel (" Agama ");
    String[] namaAgama = {"Islam", "Kristen", "Katolik", "Hindu", "Budha"};
    JComboBox cmbAgama = new JComboBox (namaAgama);
    JLabel ljeniskelamin = new JLabel (" Jenis Kelamin : " );
    JRadioButton rbPria = new JRadioButton (" Laki-Laki ");
    JRadioButton rbWanita=new JRadioButton ("Perempuan");
    JLabel lhobby = new JLabel (" Hobby ");
    JCheckBox cbsepakbola = new JCheckBox(" Sepakbola ");
    JCheckBox cbBadminton = new JCheckBox (" Badminton ");
    JButton btnSave = new JButton ("SAVE");
    public GUI()
    {    
        setTitle("FORM");
        setDefaultCloseOperation(3);
        setSize (350,300);
        
        ButtonGroup group = new ButtonGroup ();
        group.add (rbPria);
        group.add (rbWanita);
        setLayout (null);
        add (lnama);
        add (fnama);
        add (lnim);
        add (fnim);
        add (ljurusan);
        add (fjurusan);
        add (lagama); 
        add (cmbAgama); 
        add (ljeniskelamin); 
        add (rbPria); 
        add (rbWanita); 
        add (lhobby); 
        add (cbsepakbola);  
        add (cbBadminton); 
        add (btnSave); 
    // setBounds (m,n, o,p) 
    // m = posisi x; n = posisi n;
    // = panjang komponen; p = tinggi komponen 
        lnama.setBounds (10,10,120,20); 
        fnama.setBounds (130,10,150,20);
        lnim.setBounds (10,35,120,20); 
        fnim.setBounds (130,35,150,20);
        ljurusan.setBounds (10,60,120,20); 
        fjurusan.setBounds (130,60,150,20);
        lagama.setBounds (10, 85,150,20); 
        cmbAgama.setBounds (130,85, 150,20);  
        ljeniskelamin.setBounds (10, 110, 120,20); 
        rbPria.setBounds (130,110,100,20);
        rbWanita.setBounds (230,110,100,20); 
        lhobby.setBounds (10,130,120,20); 
        cbsepakbola.setBounds (130,130,100,20);
        cbBadminton.setBounds (230,130,100,20);  
        btnSave.setBounds (100,170,120, 20); 
        setVisible (true);
    }
    
}
