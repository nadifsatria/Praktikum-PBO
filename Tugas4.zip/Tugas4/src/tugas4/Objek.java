
package tugas4;
import javax.swing.*;
public class Objek 
{
    public static void main(String[] args) 
    {
        GUI g = new GUI();           
    }
}