package Attack;
public interface AttackBehaviour 
{
	public void Attack();
}
