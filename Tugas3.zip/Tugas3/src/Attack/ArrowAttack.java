package Attack;
public class ArrowAttack implements AttackBehaviour
{
	public void Attack()
	{
		System.out.println("Arrow");
	}
}
