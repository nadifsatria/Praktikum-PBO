package Attack;
public class SwordAttack implements AttackBehaviour 
{
	public void Attack()
	{
		System.out.println("Sword");
	}
}
