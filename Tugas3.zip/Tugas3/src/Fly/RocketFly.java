package Fly;
public class RocketFly implements FlyBehaviour 
{
	public void Fly()
	{
		System.out.println("Rocket");
	}
}
