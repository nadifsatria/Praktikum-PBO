package Fly;
public class WingFly implements FlyBehaviour
{
    public void Fly()
    {
    	System.out.println("Wings");
    }
}
