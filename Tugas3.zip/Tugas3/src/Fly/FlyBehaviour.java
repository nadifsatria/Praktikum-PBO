package Fly;
public interface FlyBehaviour
{
	public void Fly();
}
