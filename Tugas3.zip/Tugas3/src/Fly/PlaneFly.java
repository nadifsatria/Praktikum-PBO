package Fly;
public class PlaneFly implements FlyBehaviour
{
    public void Fly()
    {
        System.out.println("Plane");
    }    
}
