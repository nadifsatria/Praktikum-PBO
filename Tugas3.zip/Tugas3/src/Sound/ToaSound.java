package Sound;
public class ToaSound implements SoundBehaviour
{
    public void Sound()
    {
        System.out.println("Toa");
    }
    
}
