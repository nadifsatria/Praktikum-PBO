package Sound;
public interface SoundBehaviour 
{
    
    public void Sound();
}
