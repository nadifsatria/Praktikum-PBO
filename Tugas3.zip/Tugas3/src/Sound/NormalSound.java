package Sound;
public class NormalSound implements SoundBehaviour
{
    public void Sound()
    {
        System.out.println("Normal");
    }
}
