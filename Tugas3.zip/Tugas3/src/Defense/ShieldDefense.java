package defense;
public class ShieldDefense implements DefenseBehaviour
{
	public void defense()
	{
		System.out.println("Shield");
	}
}
