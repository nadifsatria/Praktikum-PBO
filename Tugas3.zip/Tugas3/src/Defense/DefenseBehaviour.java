package defense;
public interface DefenseBehaviour 
{
	public void defense();
}
