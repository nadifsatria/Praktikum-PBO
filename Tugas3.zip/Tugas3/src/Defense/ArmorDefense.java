package defense;
public class ArmorDefense implements DefenseBehaviour
{
	public void defense()
	{
		System.out.println("Armor");
	}
}
