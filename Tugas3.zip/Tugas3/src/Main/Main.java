package Main;
import Attack.*;
import defense.*;
import Fly.*;
import Sound.*;
public class Main
{
    public static void main(String[] args) 
	{
	System.out.println("Super Duck Behaviour");
	Duck sup = new Duck(new ArrowAttack() , new ShieldDefense() , new RocketFly() , new ToaSound());
	sup.fly();
	sup.sound();
	sup.attack();
	sup.defense();
	System.out.println("");
	System.out.println("Noob Duck Behaviour");
	Duck noob = new Duck(new SwordAttack() , new ArmorDefense() , new WingFly() , new NormalSound());
	noob.fly();
	noob.sound();
	noob.attack();
	noob.defense();
	System.out.println("");
	System.out.println("Super Duck Change Fly Behavior");
	sup = new Duck(new ArrowAttack() , new ShieldDefense() , new PlaneFly() , new ToaSound());
	sup.fly();
	sup.sound();
	sup.attack();
	sup.defense();
        }
}
